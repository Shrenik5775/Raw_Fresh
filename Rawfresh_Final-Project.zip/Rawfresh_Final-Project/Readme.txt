System configuration: Windows 10 and Above

*Steps to install and run to the Project-

1)Install Python 3.10.6
2)Install Django 3.5.2
3)Install Django Framework
4)Install pytz 2022.1
5)Install Pillow 9.2.0
6)Install MySQL 2.1.1
7)Install Djongo 4.4.1
8)Install MongoDB server 4.2.20
9)Start MongoDB server Connection in services.
10)Connect to MongoDB server.
11)Run project in command Prompt by command- python manage.py runserver.
12)Copy the web page address and paste in the web browser then press enter.
