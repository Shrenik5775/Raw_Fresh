from django.shortcuts import render
from raw_material.models import AdminMaster
from raw_material.models import Product
from raw_material.models import Vendor
from raw_material.models import Order
from raw_material.models import Cart
from raw_material.models import Review
from raw_material.models import Register
from raw_material.models import Contact
from raw_material.models import PurchasedProducts
from django.http import HttpResponse
from django.contrib.auth.models import Permission
from django.http import  JsonResponse
import pymongo
from rest_framework import serializers
import json
import datetime
# from pymongo import MongoClient

# login

def openLogin(request):
	return render(request, 'index.html', {})

def login(request):
	if request.POST['selRole'] == "Admin":
		if AdminMaster.objects.filter(ad_email=request.POST['txtEmail'], ad_password=request.POST['txtPassword']).count():
			products_json = AdminMaster.objects.filter(ad_email=request.POST['txtEmail']).values()
			data = list(products_json)
			dictValue = data[0]
			request.session['email'] = dictValue['ad_email']
			request.session['role'] = dictValue['ad_role']
			request.session['name'] = dictValue['ad_name']
			return HttpResponse(dictValue['ad_role'])
		else:
			return HttpResponse("0")
	else:
		if Vendor.objects.filter(vd_email=request.POST['txtEmail'], vd_password=request.POST['txtPassword']).count():
			products_json = Vendor.objects.filter(vd_email=request.POST['txtEmail']).values()
			data = list(products_json)
			dictValue = data[0]
			request.session['email'] = dictValue['vd_email']
			request.session['role'] = dictValue['vd_role']
			request.session['name'] = dictValue['vd_name']
			return HttpResponse(dictValue['vd_role'])
		else:
			return HttpResponse("0")

def logout(request):
	request.session.delete();
	return render(request, 'index.html', {});

def webLogout(request):
	request.session.delete()
	return render(request, 'web/web_index.html', {});


# admin details
def adminMaster(request):
	return render(request, 'admin/admin_master.html', {})

def getData(request):

	products_json = AdminMaster.objects.filter(ad_status='0').values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def add(request):
	lclID = AdminMaster.objects.count()
	status = "0"
	request.session['username'] = request.POST['txtEmail']

	lclNewID = lclID + 1

	AdminMaster.objects.create (
		ad_id = lclNewID,
		ad_name = request.POST['txtName'],
		ad_mobile = request.POST['txtMobileNo'],
		ad_email = request.POST['txtEmail'],
		ad_password = request.POST['txtPassword'],
		ad_role = request.POST['selRole'],
		ad_status = status
		# ad_created_by = request.session['email']

	)

	return HttpResponse()
	# post.save()
	# pass

def update(request):
	AdminMaster.objects.filter(ad_id = request.POST['id']).update(ad_name = request.POST['txtName1'], ad_mobile = request.POST['txtMobileNo1'], ad_email = request.POST['txtEmail1'], ad_role = request.POST['selRole1'])
	return HttpResponse()
	# pass

def delete(request):

	AdminMaster.objects.filter(ad_id = request.POST['id']).update(ad_status = "1")
	return HttpResponse()

# product details
def product(request):

	if 'email' in request.session:
		if request.session['role'] == "Admin":
			return render(request, 'admin/product.html', {})
		else:
			return render(request, 'vendor/product.html', {})

	else:
		return render(request, 'index.html', {})

def getProductData(request):
	if request.session['role'] == "Admin":
		products_json = Product.objects.filter(ap_status='0').values()
		data = list(products_json)
		value = JsonResponse(data, safe=False)
		return value
	else:
		# print(request.session['email'])
		products_json = Product.objects.filter(ap_status='0', ap_created_by=request.session['email']).values()
		data = list(products_json)
		value = JsonResponse(data, safe=False)
		return value


def addProduct(request):
	# post = AdminMaster(first_name=request.POST.get("Karthik"), last_name=request.POST.get("Hanasi"))
	# count collection
	lclID = Product.objects.count()
	status = "0"
	lclNewID = lclID + 1

	Product.objects.create (
		ap_id = lclNewID,
		ap_image = request.FILES["filePhoto"],
		ap_type = request.POST["selType"],
		ap_name = request.POST['txtName'],
		ap_weight = request.POST['txtWeight'],
		ap_rate = request.POST['txtRate'],
		ap_description = request.POST['txtDesc'],
		ap_status = status,
		ap_created_by = request.session['email'],
		ap_created_name = request.session['name']

	)

	return HttpResponse()

def updateProduct(request):
	Product.objects.filter(ap_id = request.POST['id']).update(ap_type = request.POST['selType1'], ap_name = request.POST['txtName1'], ap_weight = request.POST['txtWeight1'], ap_rate = request.POST['txtRate1'], ap_description = request.POST['txtDesc1'])
	return HttpResponse()
	# pass

def deleteProduct(request):

	Product.objects.filter(ap_id = request.POST['id']).update(ap_status = "1")
	return HttpResponse()


# vendor details

def vendor(request):
	if 'email' in request.session:
		if request.session['role'] == "Admin":
			return render(request, 'admin/vendor.html', {})
		else:
			return render(request, 'vendor/vendor.html', {})
	else:
		return render(request, 'index.html', {})


def getVendorData(request):

	products_json = Vendor.objects.filter(vd_role='Vendor',vd_status="0").values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value


def addVendor(request):
	# count collection
	lclID = Vendor.objects.count()
	status = "0"
	lclNewID = lclID + 1

	Vendor.objects.create (
		vd_id = lclNewID,
		vd_name = request.POST['txtName'],
		vd_mobile = request.POST['txtMobileNo'],
		vd_email = request.POST['txtEmail'],
		vd_password = request.POST['txtPassword'],
		vd_role = request.POST['selRole'],
		# vd_address = request.POST['txtAddress'],
		vd_status = status,
		vd_created_by = request.session['email']

	)

	return HttpResponse()
	# post.save()
	# pass

def updateVendor(request):
	Vendor.objects.filter(vd_id = request.POST['id']).update(
		vd_name = request.POST['txtName1'], 
		vd_mobile = request.POST['txtMobileNo1'], 
		vd_email = request.POST['txtEmail1'], 
		vd_role = request.POST['selRole1'],
	)
	return HttpResponse()
	# pass

def deleteVendor(request):

	Vendor.objects.filter(vd_id = request.POST['id']).update(vd_status = "1")
	return HttpResponse()


# order details

def order(request):
	if 'email' in request.session:
		if request.session['role'] == "Admin":
			return render(request, 'admin/order.html', {})
		else:
			return render(request, 'vendor/order.html', {})
	return render(request, 'index.html', {})

def getOrderData(request):
	if request.session['role'] == "Admin":
		products_json = PurchasedProducts.objects.filter(ps_status="0").values()
		data = list(products_json)
		value = JsonResponse(data, safe=False)
		return value
	else:
		products_json = PurchasedProducts.objects.filter(ps_vendor_email = request.session['email']).values()
		data = list(products_json)
		value = JsonResponse(data, safe=False)
		return value

# web views starts
def webIndex(request):
	return render(request, 'web/web_index.html', {})

def about(request):
	return render(request, 'web/about.html', {})

def contact(request):
	return render(request, 'web/contact.html', {})

def admin_contact(request):
	return render(request, 'admin/admin_contact.html', {})

def checkout(request):
	print(request.GET.get('qty'));
	return render(request, 'web/checkout.html', {})

def shop(request):
	return render(request, 'web/shop.html', {})

def single(request):
	# print()
	request.session['product_id'] = request.GET.get('id')
	return render(request, 'web/single.html', {})

def payment(request):
	return render(request, 'web/payment.html', {})

def paymentSuccess(request):
	
	Order.objects.filter(or_ordered_by = request.session['web_email'], or_status = "0").update(or_transaction_id = request.GET.get('transaction_id'), or_status = "1")
	Cart.objects.filter(ct_ordered_by = request.session['web_email']).update(ct_status = "1")
	return render(request, 'web/pay_success.html', {})

def cart(request):
	return render(request, 'web/cart.html', {})

def addCart(request):

	if 'web_email' in request.session:
		products_json = Product.objects.filter(ap_id=request.session['product_id']).values()
		data = list(products_json)
		dictValue = data[0]

		lclID = Cart.objects.count()
		status = "0"
		lclNewID = lclID + 1

		Cart.objects.create (
			ct_id = lclNewID,
			ct_name = dictValue['ap_name'],
			ct_image = dictValue['ap_image'],
			ct_weight = request.POST['selQTY'],
			ct_price = dictValue['ap_rate'],
			ct_total_amount = request.POST['txtTotalAmt'],
			ct_ordered_by = request.session['web_email'],
			ct_status = status,
			ct_created_by = dictValue['ap_created_by'],

		)
		return HttpResponse('1')
	else:
		return HttpResponse('0')

def getCart(request):
	cart_json = Cart.objects.filter(ct_status='0', ct_ordered_by = request.session['web_email']).values()
	data = list(cart_json)
	value = JsonResponse(data, safe=False)
	return value

def register(request):
	return render(request, 'web/register.html', {})

def newRegister(request):

	if Register.objects.filter(rg_email=request.POST['txtEmail'], rg_mobile=request.POST['txtMobileNo']).exists():
		return HttpResponse('10')
	else:
		lclID = Register.objects.count()
		status = "0"
		lclNewID = lclID + 1

		Register.objects.create (
			rg_id = lclNewID,
			rg_name = request.POST['txtName'],
			rg_mobile = request.POST['txtMobileNo'],
			rg_email = request.POST['txtEmail'],
			rg_password = request.POST['txtPassword'],
			rg_address = request.POST['txtAddress'],

		)

		return HttpResponse('0')

def webLogin(request):
	if Register.objects.filter(rg_email=request.POST['txtEmailLogin'], rg_password=request.POST['txtPasswordLogin']).count():
		request.session['web_email'] = request.POST['txtEmailLogin']
		return HttpResponse("1")
	else:
		return HttpResponse("0")
    	

def checkoutPayment(request):
	lclID = Order.objects.count()
	status = "0"
	lclNewID = lclID + 1

	Order.objects.create (
		or_id = lclNewID,
		or_name = request.POST['txtName'],
		or_weight = 0,
		or_rate = 0,
		or_total_amount = request.POST['totalAmt'],
		or_address = request.POST['txtAddress'],
		or_date = request.POST['txtDate'],
		or_time = request.POST['txtTime'],
		or_ordered_by = request.session['web_email'],
		or_status = status,
		or_cancel_status = "Ordered",
		or_created_by = request.POST['txtVendor'],

	)

	productImage = request.POST['productImage'].split("<>")
	productQTY = request.POST['productQTY'].split("<>")
	productName = request.POST['productName'].split("<>")
	productPrice = request.POST['productPrice'].split("<>")
	productTotal = request.POST['productTotal'].split("<>")
	productVendor = request.POST['productVendor'].split("<>")
	k = 0;

	for i in productQTY:

		lclID1 = PurchasedProducts.objects.count()
		status = "0"
		lclNewID1 = lclID1 + 1

		now = datetime.datetime.now()
		dateNow = now.strftime("%Y-%m-%d")

		PurchasedProducts.objects.create (
			ps_id = lclNewID1,
			ps_or_id = lclNewID,
			ps_product_name = productName[k],
			ps_image = productImage[k],
			ps_weight = productQTY[k],
			ps_price = productPrice[k],
			ps_total_amt = productTotal[k],
			ps_date = dateNow,
			ps_status = status,
			ps_vendor_email = productVendor[k],
			ps_user_name = request.POST['txtName'],
			ps_user_email = request.session['web_email']
		)

		k += 1

	return HttpResponse()

def checkCheckout(request):
	if 'web_email' in request.session:
		return HttpResponse(request.session['product_id'])
	else:
		return HttpResponse(0)

def getBuyNowURL(request):

	products_json = Product.objects.filter(ap_id=request.POST['txtID']).values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def getHomeDetails(request):
	products_json = Product.objects.filter(ap_status='0', ap_type='New')[:4].values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def getHomeSlider(request):
	products_json = Product.objects.filter(ap_status='0')[:10].values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def getSingleItem(request):
	products_json = Product.objects.filter(ap_id=request.session['product_id']).values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def getReview(request):
	products_json = Review.objects.filter(rv_ap_id=request.session['product_id']).values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def submitReview(request):

	lclID = Review.objects.count()
	status = "0"
	lclNewID = lclID + 1

	Review.objects.create (
		rv_id = lclNewID,
		rv_ap_id = request.session['product_id'],
		rv_name = request.POST['txtName'],
		rv_email = request.POST['txtEmail'],
		rv_message = request.POST['txtMessage'],
		rv_status = status,
	)

	return HttpResponse()

def saveContact(request):
	lclID = Contact.objects.count()
	status = "0"
	lclNewID = lclID + 1

	Contact.objects.create (
		co_id = lclNewID,
		co_name = request.POST['txtName'],
		co_email = request.POST['txtEmail'],
		co_mobile = request.POST['txtMobileNo'],
		co_subject = request.POST['txtSubject'],
		co_message = request.POST['txtMessage'],
		co_status = status,
	)

	return HttpResponse()

def getContact(request):
	getData = Contact.objects.filter().values()
	data = list(getData)
	value = JsonResponse(data, safe=False)
	return value

def webOrders(request):
	return render(request, 'web/web_orders.html', {})

def getOrders(request):
	products_json = Order.objects.filter(or_ordered_by=request.session['web_email'], or_status="1").values()
	data = list(products_json)
	value = JsonResponse(data, safe=False)
	return value

def cancelItem(request):
    Cart.objects.filter(ct_id = request.POST['id']).update(ct_status = "1");
    return HttpResponse()

def cancelOrder(request):
    Order.objects.filter(or_id = request.POST['id']).update(or_status = "10");
    return HttpResponse();

def getProfile(request):
	if 'web_email' in request.session:
		products_json = Register.objects.filter(rg_email=request.session['web_email']).values()
		data = list(products_json)
		value = JsonResponse(data, safe=False)
		return value
	else:
		return HttpResponse();

def webForgotPassword(request):
    return render(request, 'web/web_forgot_password.html');

def webUpdatePassword(request):
    return render(request, 'web/web_update_password.html');

def checkEmail(request):
    if Register.objects.filter(rg_email=request.POST['txtEmail']).count():
        request.session['forgot_email'] = request.POST['txtEmail'];
        return HttpResponse("1");
    else:
        return HttpResponse("10");

def updatePassword(request):
    Register.objects.filter(rg_email=request.session['forgot_email']).update(
        rg_password = request.POST['txtPassword']
    );

    return HttpResponse("1");