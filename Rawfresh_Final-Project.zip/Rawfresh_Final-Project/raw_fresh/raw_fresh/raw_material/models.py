from django.db import models

# Create your models here.

class AdminMaster(models.Model):
	ad_id = models.AutoField(primary_key=True, unique = True)
	ad_name = models.CharField(max_length=100)
	ad_mobile = models.CharField(max_length=100)
	ad_email = models.CharField(max_length=100)
	ad_password = models.CharField(max_length=100)
	ad_role = models.CharField(max_length=100)
	ad_status = models.CharField(max_length=100)
	ad_created_by = models.CharField(max_length=100)

class Product(models.Model):
	ap_id = models.AutoField(primary_key=True, unique = True)
	ap_image = models.ImageField(upload_to="raw_material/static/media/products/")
	ap_type = models.CharField(max_length=100)
	ap_name = models.CharField(max_length=100)
	ap_weight = models.CharField(max_length=100)
	ap_rate = models.CharField(max_length=100)
	ap_description = models.CharField(max_length=100)
	ap_status = models.CharField(max_length=100)
	ap_created_by = models.CharField(max_length=100)
	ap_created_name = models.CharField(max_length=100)

class Vendor(models.Model):
	vd_id = models.AutoField(primary_key=True, unique = True)
	vd_name = models.CharField(max_length=100)
	vd_mobile = models.CharField(max_length=100)
	vd_email = models.CharField(max_length=100)
	vd_password = models.CharField(max_length=100)
	vd_role = models.CharField(max_length=100)
	vd_address = models.CharField(max_length=100, default="")
	vd_status = models.CharField(max_length=100)
	vd_created_by = models.CharField(max_length=100)

class Order(models.Model):
	or_id = models.AutoField(primary_key=True, unique = True)
	or_name = models.CharField(max_length=100)
	or_weight = models.CharField(max_length=100)
	or_rate = models.CharField(max_length=100)
	or_total_amount = models.CharField(max_length=100)
	or_address = models.CharField(max_length=100)
	or_ordered_by = models.CharField(max_length=100)
	or_date = models.CharField(max_length=100)
	or_time = models.CharField(max_length=100,default="")
	or_cancel_status = models.CharField(max_length=100,default="")
	or_transaction_id = models.CharField(max_length=100)
	or_status = models.CharField(max_length=100)
	or_created_by = models.CharField(max_length=100)

class Shipping(models.Model):
	sh_id = models.AutoField(primary_key=True, unique = True)
	sh_shipping_status = models.CharField(max_length=100)
	sh_ordered_by = models.CharField(max_length=100)
	sh_status = models.CharField(max_length=100)
	sh_created_by = models.CharField(max_length=100)

class Cart(models.Model):
	ct_id = models.AutoField(primary_key=True, unique = True)
	ct_name = models.CharField(max_length=100)
	ct_image = models.CharField(max_length=100)
	ct_weight = models.CharField(max_length=100)
	ct_price = models.CharField(max_length=100)
	ct_total_amount = models.IntegerField()
	ct_ordered_by = models.CharField(max_length=100)
	ct_status = models.CharField(max_length=100)
	ct_created_by = models.CharField(max_length=100)

class Review(models.Model):
	rv_id = models.AutoField(primary_key=True, unique = True)
	rv_ap_id = models.CharField(max_length=100)
	rv_name = models.CharField(max_length=100)
	rv_email = models.CharField(max_length=100)
	rv_message = models.CharField(max_length=100)
	rv_status = models.CharField(max_length=100)

class Register(models.Model):
	rg_id = models.AutoField(primary_key=True, unique = True)
	rg_name = models.CharField(max_length=100)
	rg_mobile = models.CharField(max_length=100)
	rg_email = models.CharField(max_length=100)
	rg_password = models.CharField(max_length=100)
	rg_address = models.CharField(max_length=100)
	rg_secret_key = models.CharField(max_length=100, default="")
	rg_status = models.CharField(max_length=100)

class Contact(models.Model):
	co_id = models.AutoField(primary_key=True, unique = True)
	co_name = models.CharField(max_length=100)
	co_mobile = models.CharField(max_length=100)
	co_email = models.CharField(max_length=100)
	co_subject = models.CharField(max_length=100)
	co_message = models.CharField(max_length=100)
	co_status = models.CharField(max_length=100)


class PurchasedProducts(models.Model):
	ps_id = models.AutoField(primary_key=True, unique = True)
	ps_or_id = models.CharField(max_length=100)
	ps_product_name = models.CharField(max_length=100)
	ps_image = models.ImageField(upload_to="raw_material/static/media/orders/")
	ps_weight = models.CharField(max_length=100)
	ps_price = models.CharField(max_length=100)
	ps_total_amt = models.CharField(max_length=100)
	ps_date = models.CharField(max_length=100)
	ps_status = models.CharField(max_length=100)
	ps_user_name = models.CharField(max_length=100)
	ps_user_email = models.CharField(max_length=100)
	ps_vendor_email = models.CharField(max_length=100)